// Configure this to the public URL of your separately hosted backend.
// Example: window.CCX_API_BASE = "https://api.your-domain.com/api";
window.CCX_API_BASE = "http://localhost:4000/api";
