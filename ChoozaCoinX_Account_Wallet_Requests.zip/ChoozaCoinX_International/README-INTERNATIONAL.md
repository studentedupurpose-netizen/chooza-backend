# ChoozaCoinX — account and wallet-request starter

This package adds persistent API-backed signup/login and authenticated deposit/withdrawal **request intake**. It is not a licensed exchange and it does not move, receive, custody, credit, or debit customer funds. Trading is disabled in the browser. Public prices are reference data only.

## What works after deployment
- Signup and login against the Node.js API; passwords are hashed with bcrypt and accounts are stored in PostgreSQL.
- Authenticated deposit request (asset, network, amount, transaction hash) and withdrawal request (asset, network, amount, destination address).
- Customers can view their request history.
- An operator can review requests through API-key-protected admin endpoints.
- Requests remain pending until an operator changes their review status. Status changes do not transfer funds.

## Important limitations
- No blockchain deposit addresses, node/provider integration, custody, private-key signing, payment rails, or actual withdrawals. Do not send funds to this website.
- No live trading, order matching, liquidity, or account balance ledger is enabled in the frontend.
- No email OTP/verification, password reset, MFA, production KYC/AML/sanctions, travel-rule, fraud controls, audit-grade controls, security audit, or regulatory approval.
- The admin API key is a starter control, not a full admin identity/role system. Do not expose it in frontend files.
- Before any real-money operation, obtain the applicable VASP licence and legal advice, engage regulated custody/payment providers, implement full compliance and security controls, and commission independent penetration/security and financial-ledger reviews.

## 1. Run the backend locally
Requirements: Node.js 20+, npm, Docker.

```bash
cd backend
cp .env.example .env
```

Edit `.env`: set a unique random `JWT_SECRET` (32+ characters), a separate strong `ADMIN_API_KEY`, and update `FRONTEND_ORIGIN` to the exact website origin. Then start PostgreSQL and API:

```bash
docker compose up -d db
npm install
npm start
```

API health: `http://localhost:4000/api/health`

The schema is mounted into the database on its first initialization. For an existing database, apply the updated schema manually from the backend directory:

```bash
docker compose exec -T db psql -U ccx -d choozacoinx < sql/schema.sql
```

## 2. Connect the Netlify frontend
Edit `config.js` and replace the local API URL with your deployed backend URL, for example:

```js
window.CCX_API_BASE = "https://YOUR-BACKEND-DOMAIN/api";
```

Set the backend `FRONTEND_ORIGIN` to your exact Netlify domain (no trailing slash), restart the API, then upload the contents of this folder to Netlify. Netlify hosts the static frontend; it does not host this Node/Postgres API. Deploy the backend and database separately. Use HTTPS.

## 3. Operator request review API
Keep `ADMIN_API_KEY` only on the server. Use the following endpoints from a secure admin environment (never from public browser JavaScript):

- `GET /api/admin/wallet-requests` with header `x-admin-key: YOUR_ADMIN_API_KEY`
- `PATCH /api/admin/wallet-requests/REQUEST_UUID` with JSON body, e.g. `{"status":"under_review","adminNote":"Reviewing details"}`
- Allowed statuses: `under_review`, `rejected`, `completed_recorded`. `completed_recorded` is only an operator record; this endpoint never sends funds.

Customer endpoints require `Authorization: Bearer <token>`:
- `POST /api/auth/register` and `POST /api/auth/login`
- `POST /api/wallet/deposit-requests`
- `POST /api/wallet/withdrawal-requests`
- `GET /api/wallet/requests`

## Before public launch
Do not accept customer funds. Complete jurisdiction-specific licensing, company registration, KYC/AML and sanctions controls, custody/payment provider agreements, blockchain monitoring, withdrawal screening, key management, incident response, independent code/security audits, accounting/reconciliation, privacy terms, and customer support. A Dubai VARA application or company incorporation alone is not permission to operate; obtain the required final authorisation first.
