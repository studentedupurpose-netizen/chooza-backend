exports.handler = async () => ({
  statusCode: 200,
  headers: { "content-type": "application/json" },
  body: JSON.stringify({ service: "ChoozaCoinX API starter", status: "online", mode: "demo-only" })
});
