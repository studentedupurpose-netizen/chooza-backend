# ChoozaCoinX — exchange starter

## Included
- Responsive exchange-style frontend
- Public live market reference prices from CoinGecko (top 100 by market cap)
- Demo spot Buy/Sell simulator with local browser balance and order history
- Netlify configuration and a basic serverless health endpoint

## Deploy on Netlify
1. Extract `ChoozaCoinX.zip` on your computer.
2. Open Netlify and choose **Add new site → Deploy manually** (or drag the extracted folder into the deploy area).
3. Upload the extracted folder containing `index.html`, `style.css`, `app.js`, `netlify.toml`, and `netlify/`.
4. Open the generated site URL. Market data requires internet access.

## Important: this is NOT a real-money exchange
The included Buy/Sell flow is paper trading only. It stores a simulated balance and orders in the visitor's browser localStorage. It does not accept deposits, hold private keys, match independent customer orders, or process withdrawals. Live market prices are reference quotes, not executable liquidity.

## What production requires before accepting customer funds
A real independent exchange is a regulated financial/technology operation, not just a website upload. You will need, at minimum:
- A reviewed legal/compliance plan for every country where you operate (including applicable Pakistani requirements), licensing/registrations where required, KYC/AML and sanctions controls.
- A secure backend and database; never trust balances, prices, or orders submitted by a browser.
- A server-side matching engine with durable order/event storage, reconciliation, rate limits, audit logs, and tested failure recovery.
- Wallet infrastructure and key management (prefer audited custody/MPC/HSM providers), deposit monitoring, withdrawal approvals, hot/cold wallet controls, and incident response.
- Real liquidity/market-making arrangements, market surveillance, fee accounting, customer support, penetration testing, independent security audits, and operational monitoring.
- Security review and testnet/pilot testing before any production funds are enabled.

Do not add real deposit addresses or collect seed phrases/private keys in this starter. Do not advertise this demo as a live exchange. For a production build, engage qualified legal, security, and custody specialists and design the backend/database first.


**Updated account/wallet build:** see `README-INTERNATIONAL.md`. Signup/login require the separately deployed API. Deposit/withdrawal are authenticated request forms only; they do not move funds. Trading is disabled.
